# deepCleanDesktopApp.ps1
# Author: Gregory Swanson
# 11/2019
#
# Update 8/13/2021
# Add optional parameter StartMenuFolder
# 
# PowerShell script to replace the legacy DeepCleaner.exe
#
# 1. GetProductInventory - 
#    a. Typical flow: Gather details of the named edition
#    b. Nuclear flow: (not implemented) assemble a list of installed desktop apps and their details
#
# 2. CallUninstall - Call msiexec to uninstall each client edition in the inventory list
#
# 3. DoDeepCleaning - 
#    a. Delete remaining application folders in ProgramData
#    
#    For each user profile folder found:
#    b. Delete AppData\Local\%AtHocEdition% folders for each user profile folder found
#    c. Delete AppData\Local\VirtualStore\ProgramData\%AtHocEdition% folders for each user profile folder found
#
#    Registry clean up:
#    d. Clean up registry: remove orphaned Toolbar key, if present
#    e. Clean up registry: remove orphaned Run on Start value, if present
#    f. Clean up registry: remove orphaned AtHoc[edition] key in HKLM, if present
#    g. Clean up registry: remove orphaned AtHoc[edition] keys in HKCU, if present (for the logged on account only)

Param(
  [string]$Edition,  #DSW edition(s) to remove; can be CSV, CSV must be in quotes: 'AtHocGov,AtHocCorp'
  [string]$StartMenuFolder #Orphaned Start Menu folder that the client creates when it connects to a vps
)

#$Edition = "AtHocCorp"
#$Edition = "AtHocGov"
#$Edition = "AtHocGov,AtHocCorp"

Write-Host ""

$inventory = New-Object System.Collections.ArrayList

if ($Edition)
{
    #Get array, or the single value
    $arrEditions = $Edition -split ','
} else {
    Write-Host "Please specify an edition! The script will exit now." -ForegroundColor Yellow

    exit
}
if ($StartMenuFolder)
{
    Write-Host "Start menu folder: $StartMenuFolder"
} else {
    Write-Host "(Optional) Start Menu folder was not specified. Organization Start Menu folder will not be removed." -ForegroundColor Yellow
}

function GetProductInventory
{
    Write-Output "Looking for installed products."

    $UninstallKey = �SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall�
    $productsKey  = �SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products�

    Try
    {
        #Create an instance of the Registry Object and open the HKLM base key
        $hklm = [microsoft.win32.registrykey]::OpenRemoteBaseKey(�LocalMachine�,$env:computername)
    } Catch {
        Write-Host "OpenRemoteBaseKey LocalMachine failed" -ForegroundColor Red
    }

    Try
    {
        $regkeyProducts = $hklm.OpenSubKey($productsKey)
        ListInventory $regkeyProducts
    } Catch {
        Write-Host "OpenSubKey $productsKey failed" -ForegroundColor Red
    }

    Try
    {
        $regkeyProducts = $hklm.OpenSubKey($UninstallKey)
        ListInventory $regkeyProducts
    } Catch {
        Write-Host "OpenSubKey $UninstallKey failed" -ForegroundColor Red
    }

}

function ListInventory ($regkeyProducts)
{
    Try
    {
        foreach ($EditionName in $arrEditions)
        {
            #Write-Host "Looking for $EditionName"

            foreach ($productKey in $regkeyProducts.GetSubKeyNames())
            {
                #Write-Host $productKey

                $subkeysProduct = $regkeyProducts.OpenSubKey($productKey)

                foreach ($subkeyProduct in $subkeysProduct.GetSubKeyNames())
                {

                    if ($subkeyProduct -eq "InstallProperties")
                    {
                        $installPropsKey = $subkeysProduct.OpenSubKey($subkeyProduct)

                        $DisplayName = $installPropsKey.GetValue("DisplayName")

                        #Write-Host "$DisplayName in $productKey\$subkeyProduct"
                        if ($DisplayName)
                        {
                            #$idx = $DisplayName.IndexOf($EditionName)
                            #if ($idx -gt 0) { #$idx = $DisplayName.Indexof(�AtHoc�)

                            if ($DisplayName -eq $EditionName) {
                                #Write-Output "$DisplayName in $productKey\$subkeyProduct"
                                $item = New-Object Inventory
                                $item.OriginalEditionName = $installPropsKey.GetValue("DisplayName")
                                $item.UninstallString = $installPropsKey.GetValue("UninstallString")
                                GetProductCode $item
                                $item.CommonFilesDir = [Environment]::GetFolderPath([System.Environment+SpecialFolder]::CommonApplicationData) + "\" + $EditionName
                                
                                #We need the uninstall string, so we don't uninstall
                                if ($item.UninstallString.length -gt 0) {
                                    $item.EditionName = $EditionName
                                    $inventory.Add($item) | Out-Null
                                }
                            }
                        }
                    }
                }
            }
        }

    } Catch {
        Write-Host "ListInventory failed" -ForegroundColor Red
    }
}

function GetProductCode($item)
{
    Try
    {
        $appKey = �SOFTWARE\WOW6432Node\� + $item.OriginalEditionName
        #Write-Output $appKey

        $hklm = [microsoft.win32.registrykey]::OpenRemoteBaseKey(�LocalMachine�,$computername)
        $regkeyDesktopApp = $hklm.OpenSubKey($appKey)
        if ($regkeyDesktopApp)
        {
            $productCode = $regkeyDesktopApp.GetValue("ProductCode")
            $item.MSIProductCode = $productCode
            $item.UninstallString = "MsiExec.exe /X$productCode"
            #Write-Output "ProductCode: $productCode"
        }
    } Catch {
        Write-Host "GetProductCode failed" -ForegroundColor Yellow
    }
}

function CallUninstall
{
    if ($inventory.Count -gt 0)
    {
        foreach ($item in $inventory)
        {
            $packageName = $item.OriginalEditionName
            Write-Host "Uninstalling $packageName"

            $productCode = $item.MSIProductCode

            Try
            {
                start-process "msiexec.exe" -arg "/X $productCode /qn" -Wait -ErrorVariable ErrMsg

                #This tries to use nuget and will prompt for it, so reverting to use msiexec above.
                #Uninstall-Package -Name $packageName -ErrorAction SilentlyContinue -ErrorVariable ErrMsg

                if ($ErrMsg)
                {
                    $item.UninstallError = $true
                    Write-Host $ErrMsg -ForegroundColor Red
                } else {
                    $item.UninstallError = $false
                    Write-Host "Uninstall succeeded" -ForegroundColor Green
                }
            } Catch {
                $item.UninstallError = $true
                Write-Host "Error running msiexec.exe." -ForegroundColor Red
            }
        }

    } else {
        Write-Host "No application(s) to uninstall." -ForegroundColor Yellow
    }

}

function DoDeepCleaning
{
    #delete remaining application folders in ProgramData and User AppData profile

    foreach ($item in $inventory)
    {
        #clean up C:\ProgramData
        
        if ($item.EditionName -and (-not $item.UninstallError))
        {
            $path = "C:\ProgramData\" + $item.EditionName

            Write-Host "Checking for folder $path"

            if ((Test-Path $path) -eq $true)
            {
                Write-Host "Removing folder $path"
                Remove-Item -path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg

                if ($ErrMsg)
                {
                    Write-Host $ErrMsg -ForegroundColor Red
                } else {
                    Write-Host "Remove folder succeeded" -ForegroundColor Green
                }

            } else {
                Write-Host "No folder: $path" -ForegroundColor Green
            }
        }
    }

    #clean up User Profile folders
    $path = "C:\Users\"

    #Get a list of folders
    $userFolders = Get-ChildItem -Path $path -ErrorAction SilentlyContinue

    foreach ($folder in $userFolders)
    {
        #Exclude .NET folders and hidden folders
        if ($folder.Name.IndexOf('.NET ') -lt 0 `
        -and $folder.Name.IndexOf('AppPool') -lt 0 `
        -and $folder.Name.IndexOf('Public') -lt 0)
        {
            #Find the AppData folder
            foreach ($item in $inventory)
            {
                if ($item.EditionName -and (-not $item.UninstallError))
                {
                    $path = $folder.FullName + "\AppData\Local\" + $item.EditionName

                    Write-Host "Checking for folder $path"

                    if ((Test-Path $path) -eq $true)
                    {
                        Write-Host "Removing folder $path"
                        Remove-Item -path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                        if ($ErrMsg)
                        {
                            Write-Host $ErrMsg -ForegroundColor Red
                        } else {
                            Write-Host "Remove folder succeeded" -ForegroundColor Green
                        }
                    } else {
                        Write-Host "No folder: $path" -ForegroundColor Green
                    }
                }
            }

            #We can remove anything that the client created in \AppData\Local\VirtualStore\ProgramData\<AtHocEdition>,
            #they are created there when the client does not have permission to create folders/files in c:\programdata,
            #and it will recreate them if not fully cleaned up.

            foreach ($EditionName in $arrEditions)
            {
                #Clean up log files written to the user's VirtualStore folder
                $path = $folder.FullName + "\AppData\Local\VirtualStore\ProgramData\$EditionName"
                Write-Host "Checking for folder $path"

                if ((Test-Path $path) -eq $true)
                {
                    Write-Host "Removing folder $path"
                    Remove-Item -path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                    if ($ErrMsg)
                    {
                        Write-Host $ErrMsg -ForegroundColor Red
                    } else {
                        Write-Host "Remove folder succeeded" -ForegroundColor Green
                    }
                } else {
                    Write-Host "No folder: $path" -ForegroundColor Green
                }
            }

            #Remove specified Start menu folder
            if ($StartMenuFolder -and (-not $item.UninstallError))
            {
                $path = $folder.FullName + "\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\" + $StartMenuFolder

                Write-Host "Checking for folder $path"
                if ((Test-Path $path) -eq $true)
                {
                    Write-Host "Removing folder $path"
                    Remove-Item -path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                    if ($ErrMsg)
                    {
                        Write-Host $ErrMsg -ForegroundColor Red
                    } else {
                        Write-Host "Remove folder succeeded" -ForegroundColor Green
                    }

                } else {
                    Write-Host "No folder: $path" -ForegroundColor Green
                }

            }
        }
    }

    #Clean up registry
    #hkcu? Client is supposed to overwrite the values in hkcu, if present, when install date does not match the copy in hklm

    #hklm
    #Check for and remove orphaned Toolbar key - Toolbar functionality was removed from the product so this key is useless
    #and we don't want the toolbar showing.

    Write-Output "Checking for Toolbar registry key"
    $path = "HKLM:\Software\WOW6432Node\Microsoft\Internet Explorer\Toolbar\{DAF2720A-F5AA-4114-BC8A-B7F3E7F8EF85}"

    if ((Test-Path $path) -eq $true)
    {
        Write-Host "Removing $path"
        Remove-Item -Path $path -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
        if ($ErrMsg)
        {
            Write-Host $ErrMsg -ForegroundColor Red
        } else {
            Write-Host "Remove registry key succeeded" -ForegroundColor Green
        }
    } else {
        Write-Host "No registry key: $path" -ForegroundColor Green
    }


    foreach ($item in $inventory)
    {
        if ($item.EditionName -and (-not $item.UninstallError))
        {
            $EditionName = $item.EditionName

            #Check for and remove orphaned Run on Start values for specified edition(s)
            Write-Host "Checking for Run on Start registry key for $EditionName"

            $path = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run"

            if ((Get-ItemProperty $path).PSObject.Properties.Name -contains $EditionName)
            {
                Write-Host "Removing $EditionName value from $path"
                Remove-ItemProperty -Path $path -Name $EditionName -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                if ($ErrMsg)
                {
                    Write-Host $ErrMsg -ForegroundColor Red
                } else {
                    Write-Host "Remove registry value Run succeeded" -ForegroundColor Green
                }
            } else {
                Write-Host "No Run on Start registry value for $EditionName" -ForegroundColor Green
            }

            #Check for and remove orphaned AtHoc[edition] keys in HKLM for specified edition(s)
            Write-Host "Checking for orphaned $EditionName key in HKLM"
            $path = "HKLM:\Software\WOW6432Node\$EditionName"

            if ((Test-Path $path) -eq $true)
            {
                Write-Host "Removing $path"
                Remove-Item -Path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                if ($ErrMsg)
                {
                    Write-Host $ErrMsg -ForegroundColor Red
                } else {
                    Write-Host "Orphaned registry key removed successfully" -ForegroundColor Green
                }
            } else {
                Write-Host "No registry key: $path" -ForegroundColor Green
            }

            #Check for and remove orphaned AtHoc[edition] keys in HKCU for specified edition(s)
            Write-Host "Checking for orphaned $EditionName key in HKCU"
            $path = "HKCU:\Software\$EditionName"

            if ((Test-Path $path) -eq $true)
            {
                Write-Host "Removing $path"
                Remove-Item -Path $path -Recurse -ErrorAction SilentlyContinue -ErrorVariable ErrMsg
                if ($ErrMsg)
                {
                    Write-Host $ErrMsg -ForegroundColor Red
                } else {
                    Write-Host "Orphaned key removed successfully" -ForegroundColor Green
                }
            } else {
                Write-Host "No registry key: $path" -ForegroundColor Green
            }
        }
    }

    #Legacy:
    #HKEY_CLASSES_ROOT\VirtualStore\MACHINE\SOFTWARE\WOW6432Node\AtHocGov
    #HKEY_CLASSES_ROOT\VirtualStore\MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Extensions\{D2490E6A-1A5E-4997-A6F8-24ECB9D5FF93}
}


#Create a log file
Try
{
    Start-Transcript -OutputDirectory $PSScriptRoot -NoClobber
}
Catch
{
    Write-Host "Error - Unable to start log." -ForegroundColor Red
    exit
}

Write-Host "Cleaning up $Edition"

GetProductInventory
CallUninstall
DoDeepCleaning


Write-Host "`nFinished." -ForegroundColor Green
Stop-Transcript

class Inventory {
    [string]$MSIProductCode
    [string]$CommonFilesDir
    [string]$UserDirs
    [string]$OriginalEditionName
    [string]$UninstallString
    [string]$EditionName
    [bool]$UninstallError
}


function Read-RegistryKey([string]$path,[string]$subkey) #returns value of specified Registry subkey
{
    Try
    {
        $keyValue = Get-ItemProperty $path  -ErrorAction Stop | Select-Object -ExpandProperty $subkey -ErrorAction Stop
        return $keyValue
    }
    Catch
    {
        return $null
    }
}

function Update-Registry ([string]$id,[string]$description) #inserts current hotfix record into Registry
{
    if (-not (Test-Path $registryPatchesPath))
    {
        New-Item $registryPatchesPath | Out-Null
    }

    New-ItemProperty $registryPatchesPath -name $id -value $description -Force | Out-Null

}

