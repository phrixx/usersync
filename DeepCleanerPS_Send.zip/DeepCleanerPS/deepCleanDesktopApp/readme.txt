This copy of deepCleanDesktopApp.ps1 takes two parameters:
1. Desktop client name to remove (required)
2. Windows Start Menu folder to remove (optional)

Make certain that the file you received (.zip) is not blocked:
   - Right click ZIP file
   - Click Properties
   - Go to the "General" tab
   - Click on "Unblock file"
   - Click OK

1) Run powershell.exe as administrator.

2) Type: "cd '[path]'" where [path] is the folder where you put 
   deepCleanDesktopApp.ps1, press enter. Make sure [path] is enclosed in single
   quotes ''.

3) Allow script execution:
	> Set-ExecutionPolicy Unrestricted (type 'y' and press enter when prompted)

4) You can specify a list of desktop app editions to remove in a comma separated
   list (CSV). The CSV must be in quotes: 'AtHocGov,AtHocCorp' 

(Optional) You can specify a single Start Menu folder for this script to remove. 
This part of the script will execute even if there is no desktop app installed. 

Example usage:
Remove AtHocGov client:
.\deepCleanDesktopApp.ps1 "AtHocGov"
Remove AtHocGov and AtHocCorp clients:
.\deepCleanDesktopApp.ps1 "AtHocGov,AtHocCorp"
Remove AtHocGov client and AtHocGov Desktop Start Menu folder:
.\deepCleanDesktopApp.ps1 "AtHocGov" "AtHocGov Desktop"

